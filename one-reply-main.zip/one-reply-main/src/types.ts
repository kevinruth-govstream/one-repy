// Shared types for OneReply application
export type DeptKey = 'transportation' | 'building' | 'utilities' | 'land_use';

// Updated section types - reduced from 6 to 3
export type SectionType = 'situation' | 'guidance' | 'nextsteps';

export interface TeamsNotificationPayload {
  ticketId: string;
  sectionId: string;
  dept: DeptKey;
  subject: string;
  summary: string;
  reviewUrl: string;
}

export interface NotifyRequest {
  flowUrl: string;
  payload: TeamsNotificationPayload;
}

export interface NotifyResponse {
  ok: boolean;
  status?: number;
  body?: string;
}