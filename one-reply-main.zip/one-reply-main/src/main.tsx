import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { loadStoreFromLocalStorage } from "./lib/storeLoader";

// Load initial data from localStorage for instant loading
loadStoreFromLocalStorage();
console.log('📦 Initial data loaded from localStorage');

const root = createRoot(document.getElementById("root")!);
root.render(<App />);
