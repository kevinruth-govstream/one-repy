import React from "react";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Navigation } from "@/components/Navigation";
import { AuthProvider } from "@/hooks/useAuth";
import { ProtectedRoute } from "@/components/ProtectedRoute";
import Index from "./pages/Index";
import Settings from "./pages/Settings";
import NewTicket from "./pages/NewTicket";
import ReviewSection from "./pages/ReviewSection";
import TinderReviewPage from "./pages/TinderReviewPage";
import TicketDetail from "./pages/TicketDetail";
import AssembleTicket from "./pages/AssembleTicket";
import Archive from "./pages/Archive";
import NotFound from "./pages/NotFound";
import Auth from "./pages/Auth";
import Landing from "./pages/Landing";
import DepartmentSelection from "./pages/DepartmentSelection";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <AuthProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <div className="min-h-screen bg-background">
            <Routes>
              <Route path="/auth" element={<Auth />} />
              <Route path="/landing" element={<Landing />} />
              <Route path="/" element={<ProtectedRoute><Navigation /><Index /></ProtectedRoute>} />
              <Route path="/settings" element={<ProtectedRoute><Navigation /><Settings /></ProtectedRoute>} />
              <Route path="/ticket/new" element={<ProtectedRoute><Navigation /><NewTicket /></ProtectedRoute>} />
              <Route path="/ticket/:ticketId" element={<ProtectedRoute><Navigation /><TicketDetail /></ProtectedRoute>} />
              <Route path="/section-review/:sectionId" element={<ProtectedRoute><Navigation /><ReviewSection /></ProtectedRoute>} />
              <Route path="/review/:ticketId" element={<ProtectedRoute><Navigation /><TinderReviewPage /></ProtectedRoute>} />
              <Route path="/review/:ticketId/:department" element={<ProtectedRoute><Navigation /><TinderReviewPage /></ProtectedRoute>} />
              <Route path="/departments/:ticketId" element={<ProtectedRoute><Navigation /><DepartmentSelection /></ProtectedRoute>} />
              <Route path="/assemble/:ticketId" element={<ProtectedRoute><Navigation /><AssembleTicket /></ProtectedRoute>} />
              <Route path="/archive" element={<ProtectedRoute><Navigation /><Archive /></ProtectedRoute>} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </div>
        </BrowserRouter>
      </AuthProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
