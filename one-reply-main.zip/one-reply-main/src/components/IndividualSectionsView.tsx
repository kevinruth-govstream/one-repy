import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import { DepartmentBadge } from './DepartmentBadge';
import { Section } from '@/lib/store';
import { ChevronDown, MessageSquare, FileText } from 'lucide-react';
import { useState } from 'react';

interface IndividualSectionsViewProps {
  sections: Section[];
  visibleSections: Set<string>;
}

export const IndividualSectionsView = ({ sections, visibleSections }: IndividualSectionsViewProps) => {
  const visibleSectionList = sections.filter(section => visibleSections.has(section.id));
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set());

  const toggleSection = (sectionId: string) => {
    setExpandedSections(prev => {
      const newSet = new Set(prev);
      if (newSet.has(sectionId)) {
        newSet.delete(sectionId);
      } else {
        newSet.add(sectionId);
      }
      return newSet;
    });
  };

  if (visibleSectionList.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        <FileText className="h-8 w-8 mx-auto mb-2 opacity-50" />
        <p>No sections visible</p>
        <p className="text-sm">Enable section visibility to see individual responses</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="text-center mb-6">
        <h3 className="text-lg font-semibold mb-2">Individual Department Responses</h3>
        <p className="text-sm text-muted-foreground">
          View each department's original response with annotations and citations
        </p>
      </div>

      {visibleSectionList.map((section, index) => {
        const isExpanded = expandedSections.has(section.id);
        const annotationCount = Array.isArray(section.annotations) ? section.annotations.length : 0;

        return (
          <Card key={section.id} className="transition-all duration-200">
            <Collapsible open={isExpanded} onOpenChange={() => toggleSection(section.id)}>
              <CollapsibleTrigger asChild>
                <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CardTitle className="text-lg capitalize">
                        {section.sectionKey.replace(/([A-Z])/g, ' $1').trim()}
                      </CardTitle>
                      <DepartmentBadge department={section.department} />
                      <Badge variant="secondary">{section.status}</Badge>
                      {annotationCount > 0 && (
                        <Badge variant="outline">
                          <MessageSquare className="h-3 w-3 mr-1" />
                          {annotationCount} notes
                        </Badge>
                      )}
                    </div>
                    <ChevronDown className={`h-4 w-4 transition-transform ${isExpanded ? 'rotate-180' : ''}`} />
                  </div>
                </CardHeader>
              </CollapsibleTrigger>

              <CollapsibleContent>
                <CardContent className="pt-0 space-y-4">
                  {/* Section Content */}
                  <div className="prose prose-sm max-w-none">
                    <div className="whitespace-pre-wrap text-foreground bg-muted/30 p-4 rounded">
                      {section.content || 'No content available'}
                    </div>
                  </div>

                  {/* Citations */}
                  {section.atoms.guidance?.citations?.length > 0 && (
                    <div className="bg-blue-50 border border-blue-200 p-3 rounded">
                      <h4 className="font-medium mb-2 text-blue-900">Referenced Regulations:</h4>
                      <ul className="space-y-1">
                        {section.atoms.guidance.citations.map((citation, citIndex) => (
                          <li key={citIndex} className="text-blue-700 text-sm">
                            <strong>{citation.code}</strong> {citation.section && `§${citation.section}`} - {citation.description}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Annotations */}
                  {annotationCount > 0 && (
                    <div className="bg-yellow-50 border border-yellow-200 p-3 rounded">
                      <h4 className="font-medium mb-2 text-yellow-900 flex items-center gap-2">
                        <MessageSquare className="h-4 w-4" />
                        Review Notes ({annotationCount})
                      </h4>
                      <div className="space-y-2">
                        {(section.annotations as string[]).map((annotation, annIndex) => (
                          <div key={annIndex} className="text-yellow-700 text-sm bg-yellow-100 p-2 rounded">
                            {annotation}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Atoms Preview (if available) */}
                  {section.atoms && Object.keys(section.atoms).length > 0 && (
                    <details className="bg-gray-50 border border-gray-200 p-3 rounded">
                      <summary className="font-medium text-gray-900 cursor-pointer">
                        Structured Data Preview
                      </summary>
                      <pre className="text-xs text-gray-600 mt-2 overflow-auto">
                        {JSON.stringify(section.atoms, null, 2)}
                      </pre>
                    </details>
                  )}

                  {index < visibleSectionList.length - 1 && <Separator />}
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        );
      })}
    </div>
  );
};