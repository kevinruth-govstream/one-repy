import { useState, useEffect, useMemo, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { toast } from '@/hooks/use-toast';
import { useDebounce } from '@/hooks/useDebounce';
import { DepartmentBadge } from './DepartmentBadge';
import SectionHtml from './SectionHtml';
import { store, getTicketSections, type Section, type Ticket, type DeptKey } from '@/lib/store';
import { normalizeContent } from '@/lib/normalize';
import { Check, X, MessageSquare, ArrowLeft, RotateCcw, Edit3, Save } from 'lucide-react';

interface TinderReviewProps {
  ticketId: string;
  department?: DeptKey;
}

// Content processor utility class for caching
class ContentProcessor {
  private cache = new Map<string, string>();
  
  getFormattedContent(section: Section): string {
    const cacheKey = `${section.id}-${section.content}`;
    
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)!;
    }
    
    const content = this.processContent(section);
    this.cache.set(cacheKey, content);
    return content;
  }
  
  private stripHtmlAndClean(text: string): string {
    if (!text) return '';
    
    try {
      const tempDiv = document.createElement('div');
      tempDiv.innerHTML = text;
      
      const blockElements = tempDiv.querySelectorAll('p, div, br, h1, h2, h3, h4, h5, h6, li');
      blockElements.forEach(el => {
        if (el.tagName.toLowerCase() === 'br') {
          el.replaceWith('\n');
        } else if (el.tagName.toLowerCase() === 'li') {
          el.insertAdjacentText('beforebegin', '• ');
          el.insertAdjacentText('afterend', '\n');
        } else {
          el.insertAdjacentText('afterend', '\n');
        }
      });
      
      let cleanText = tempDiv.textContent || tempDiv.innerText || '';
      
      cleanText = cleanText
        .replace(/\\n/g, '\n')
        .replace(/\\"/g, '"')
        .replace(/\\'/g, "'")
        .replace(/\\\\/g, '\\')
        .replace(/\n\s*\n\s*\n/g, '\n\n')
        .replace(/[ \t]+/g, ' ')
        .replace(/^\s+|\s+$/gm, '')
        .trim();
      
      return cleanText;
    } catch (error) {
      return text
        .replace(/<[^>]*>/g, '')
        .replace(/\\n/g, '\n')
        .replace(/\\"/g, '"')
        .replace(/\s+/g, ' ')
        .trim();
    }
  }
  
  private processContent(section: Section): string {
    const { atoms } = section;
    let content = '';

    switch (section.sectionKey) {
      case 'situation':
        if (atoms.situation?.understanding?.length) {
          content += 'Understanding:\n' + atoms.situation.understanding.join('\n\n') + '\n\n';
        }
        if (atoms.situation?.propertyFacts?.length) {
          content += 'Property Facts:\n' + atoms.situation.propertyFacts
            .map(fact => `• ${fact.key}: ${fact.value}`)
            .join('\n');
        }
        break;
      case 'guidance':
        if (atoms.guidance?.recommendations?.length) {
          content += 'Recommendations:\n' + atoms.guidance.recommendations
            .map(rec => `• ${rec}`)
            .join('\n') + '\n\n';
        }
        if (atoms.guidance?.citations?.length) {
          content += 'Citations:\n' + atoms.guidance.citations
            .map(cite => `• ${cite.code} ${cite.section} - ${cite.description}`)
            .join('\n');
        }
        break;
      case 'nextsteps':
        if (atoms.nextsteps?.followups?.length) {
          content += 'Follow-ups:\n' + atoms.nextsteps.followups
            .map(followup => `• ${followup}`)
            .join('\n') + '\n\n';
        }
        if (atoms.nextsteps?.actions?.length) {
          content += 'Actions:\n' + atoms.nextsteps.actions
            .map((action, i) => `${i + 1}. ${action}`)
            .join('\n');
        }
        break;
    }

    if (!content && section.content) {
      let rawContent = section.content;
      
      try {
        const htmlBacktickMatch = rawContent.match(/"html":\s*`([^`]*)`/s);
        if (htmlBacktickMatch) {
          rawContent = htmlBacktickMatch[1].trim();
        } else if (rawContent.includes('```json') || rawContent.includes('"html"')) {
          const jsonMatch = rawContent.match(/```json\s*\n?\s*{[\s\S]*?}\s*\n?\s*```/);
          if (jsonMatch) {
            const jsonStr = jsonMatch[0].replace(/```json\s*\n?\s*/, '').replace(/\s*\n?\s*```/, '');
            const parsed = JSON.parse(jsonStr);
            if (parsed.html) {
              rawContent = parsed.html;
            }
          }
        }
        
        content = this.stripHtmlAndClean(rawContent);
      } catch (error) {
        content = this.stripHtmlAndClean(section.content);
      }
    }

    return this.stripHtmlAndClean(content) || 'No content available';
  }
  
  clearCache() {
    this.cache.clear();
  }
}

const contentProcessor = new ContentProcessor();

export const TinderReview = ({ ticketId, department }: TinderReviewProps) => {
  const navigate = useNavigate();
  const [ticket, setTicket] = useState<Ticket | null>(null);
  const [sections, setSections] = useState<Section[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [annotation, setAnnotation] = useState('');
  const [showAnnotation, setShowAnnotation] = useState(false);
  const [completedCount, setCompletedCount] = useState(0);
  const [isEditing, setIsEditing] = useState(false);
  const [editedContent, setEditedContent] = useState('');
  
  // Debounce edited content to reduce re-renders
  const debouncedEditedContent = useDebounce(editedContent, 300);

  useEffect(() => {
    const currentTicket = store.getTicket(ticketId);
    if (!currentTicket) {
      toast({
        title: "Ticket not found",
        description: "The requested ticket could not be found.",
        variant: "destructive",
      });
      navigate("/");
      return;
    }

    const ticketSections = getTicketSections(ticketId);
    const pendingSections = ticketSections.filter(s => 
      s.status === 'pending' && 
      (!department || s.department === department)
    );
    
    setTicket(currentTicket);
    setSections(pendingSections);
    setCompletedCount(ticketSections.filter(s => s.status === 'approved').length);
  }, [ticketId, navigate, department]);

  // Memoized computed values
  const currentSection = useMemo(() => sections[currentIndex], [sections, currentIndex]);
  const totalSections = useMemo(() => sections.length, [sections.length]);
  const progress = useMemo(() => 
    totalSections > 0 ? ((completedCount + currentIndex) / (completedCount + totalSections)) * 100 : 0,
    [completedCount, currentIndex, totalSections]
  );

  // Memoized formatted content
  const formattedContent = useMemo(() => {
    if (!currentSection) return '';
    return contentProcessor.getFormattedContent(currentSection);
  }, [currentSection]);

  const moveToNext = useCallback(() => {
    if (currentIndex < sections.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      toast({
        title: "Review complete",
        description: `All ${department ? department + ' ' : ''}sections have been reviewed.`,
      });
      
      if (department) {
        navigate(`/departments/${ticketId}`);
      } else {
        navigate(`/assemble/${ticketId}`);
      }
    }
  }, [currentIndex, sections.length, ticketId, navigate, department]);

  const handleApprove = useCallback(() => {
    if (!currentSection) return;

    try {
      store.updateSection(currentSection.id, { status: 'approved' });
      store.applyGatingLogic(currentSection.ticketId, currentSection.department);
      
      toast({
        title: "Section approved",
        description: `${currentSection.sectionKey} section approved.`,
      });

      moveToNext();
    } catch (error) {
      toast({
        title: "Approval failed",
        description: "Failed to approve section. Please try again.",
        variant: "destructive",
      });
    }
  }, [currentSection, moveToNext]);

  const handleOmit = useCallback((withAnnotation = false) => {
    if (!currentSection) return;

    try {
      const updates: any = { status: 'omitted' };
      if (withAnnotation && annotation.trim()) {
        updates.annotations = [annotation.trim()];
      }

      store.updateSection(currentSection.id, updates);
      
      toast({
        title: "Section omitted",
        description: `${currentSection.sectionKey} section omitted.`,
      });

      setAnnotation('');
      setShowAnnotation(false);
      moveToNext();
    } catch (error) {
      toast({
        title: "Omit failed",
        description: "Failed to omit section. Please try again.",
        variant: "destructive",
      });
    }
  }, [currentSection, annotation, moveToNext]);

  const handleAnnotate = useCallback(() => {
    if (!currentSection || !annotation.trim()) return;

    try {
      store.updateSection(currentSection.id, { 
        status: 'approved',
        annotations: [annotation.trim()]
      });
      
      toast({
        title: "Section annotated & approved",
        description: `Note added to ${currentSection.sectionKey} section.`,
      });

      setAnnotation('');
      setShowAnnotation(false);
      moveToNext();
    } catch (error) {
      toast({
        title: "Annotation failed",
        description: "Failed to add annotation. Please try again.",
        variant: "destructive",
      });
    }
  }, [currentSection, annotation, moveToNext]);

  const handleUndo = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
    }
  }, [currentIndex]);

  const handleEdit = useCallback(() => {
    setEditedContent(formattedContent);
    setIsEditing(true);
  }, [formattedContent]);

  const handleSaveEdit = useCallback(() => {
    if (!currentSection || !debouncedEditedContent.trim()) return;

    try {
      store.updateSection(currentSection.id, { 
        content: debouncedEditedContent.trim(),
        status: 'approved'
      });
      
      toast({
        title: "Content updated",
        description: "Section content has been updated and approved.",
      });

      setIsEditing(false);
      setEditedContent('');
      moveToNext();
    } catch (error) {
      toast({
        title: "Save failed",
        description: "Failed to save changes. Please try again.",
        variant: "destructive",
      });
    }
  }, [currentSection, debouncedEditedContent, moveToNext]);

  const handleCancelEdit = useCallback(() => {
    setIsEditing(false);
    setEditedContent('');
  }, []);

  // Clear cache when component unmounts
  useEffect(() => {
    return () => contentProcessor.clearCache();
  }, []);

  if (!ticket || !currentSection) {
    return (
      <div className="min-h-screen bg-background p-6 flex items-center justify-center">
        <div className="animate-fade-in">
          <p className="text-muted-foreground">Loading review...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-6 animate-fade-in">
      <div className="max-w-2xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <Button 
            variant="ghost" 
            onClick={() => navigate(department ? `/departments/${ticketId}` : "/")} 
            className="flex items-center gap-2"
          >
            <ArrowLeft className="h-4 w-4" />
            {department ? 'Back to Departments' : 'Back to Dashboard'}
          </Button>
          {currentIndex > 0 && (
            <Button variant="outline" onClick={handleUndo} className="flex items-center gap-2">
              <RotateCcw className="h-4 w-4" />
              Undo
            </Button>
          )}
        </div>

        {/* Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-sm text-muted-foreground">
            <span className="flex items-center">
              {department && (
                <DepartmentBadge department={department} className="mr-2" />
              )}
              Section {currentIndex + 1} of {totalSections}
            </span>
            <span>{Math.round(progress)}% complete</span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Section Card */}
        <Card className="animate-scale-in">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">
                {currentSection.sectionKey}
              </CardTitle>
              <div className="flex items-center gap-2">
                <DepartmentBadge department={currentSection.department} />
                <Badge variant="outline" className="capitalize">
                  {currentSection.status}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Previous Annotations */}
            {currentSection.annotations && (
              <div className="p-3 bg-muted rounded-lg">
                <h4 className="text-sm font-medium mb-2">Previous Notes:</h4>
                <p className="text-sm text-muted-foreground">{currentSection.annotations}</p>
              </div>
            )}

            {/* Content Display/Edit */}
            {isEditing ? (
              <div className="space-y-3">
                <Textarea
                  value={editedContent}
                  onChange={(e) => setEditedContent(e.target.value)}
                  placeholder="Edit section content..."
                  className="min-h-[300px] font-mono text-sm"
                />
                <div className="flex gap-2">
                  <Button onClick={handleSaveEdit} size="sm">
                    <Save className="h-4 w-4 mr-1" />
                    Save & Approve
                  </Button>
                  <Button onClick={handleCancelEdit} variant="outline" size="sm">
                    Cancel
                  </Button>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <div className="max-h-[400px] overflow-y-auto border rounded-lg p-4 bg-muted/30">
                  <pre className="whitespace-pre-wrap text-sm font-mono">
                    {formattedContent}
                  </pre>
                </div>
                <Button 
                  onClick={handleEdit} 
                  variant="outline" 
                  size="sm"
                  className="w-full"
                >
                  <Edit3 className="h-4 w-4 mr-1" />
                  Edit Content
                </Button>
              </div>
            )}

            {/* Annotation Input */}
            {showAnnotation && !isEditing && (
              <div className="space-y-3 p-3 border rounded-lg bg-muted/30">
                <Textarea
                  value={annotation}
                  onChange={(e) => setAnnotation(e.target.value)}
                  placeholder="Add your note or feedback..."
                  className="min-h-[100px]"
                />
                <div className="flex gap-2">
                  <Button onClick={handleAnnotate} size="sm">
                    Add Note & Approve
                  </Button>
                  <Button 
                    onClick={() => handleOmit(true)} 
                    variant="outline" 
                    size="sm"
                  >
                    Add Note & Omit
                  </Button>
                  <Button 
                    onClick={() => setShowAnnotation(false)} 
                    variant="ghost" 
                    size="sm"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            {!showAnnotation && !isEditing && (
              <div className="flex gap-3 pt-4">
                <Button 
                  onClick={() => handleOmit(false)} 
                  variant="outline" 
                  className="flex-1"
                >
                  <X className="h-4 w-4 mr-1" />
                  Omit
                </Button>
                <Button 
                  onClick={() => setShowAnnotation(true)} 
                  variant="outline" 
                  className="flex-1"
                >
                  <MessageSquare className="h-4 w-4 mr-1" />
                  Add Note
                </Button>
                <Button 
                  onClick={handleApprove} 
                  className="flex-1"
                >
                  <Check className="h-4 w-4 mr-1" />
                  Approve
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};