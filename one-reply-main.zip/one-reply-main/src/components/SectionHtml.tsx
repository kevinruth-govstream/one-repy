import React from 'react';
import { sanitizeHtml, hasStructuredSections, validateHtmlStructure } from '@/lib/html';
import { normalizeContent } from '@/lib/normalize';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Info } from 'lucide-react';

interface SectionHtmlProps {
  html: string;
  showFormatHints?: boolean;
  className?: string;
}

export default function SectionHtml({ 
  html, 
  showFormatHints = false, 
  className = "" 
}: SectionHtmlProps) {
  
  // Process and normalize the HTML content
  const processedHtml = React.useMemo(() => {
    if (!html) return '';
    
    // First try to normalize if it's malformed
    const normalized = normalizeContent(html);
    
    // Then sanitize for safety
    const sanitized = sanitizeHtml(normalized);
    
    return sanitized;
  }, [html]);
  
  // Validate the structure for formatting hints
  const structureValidation = React.useMemo(() => {
    if (!showFormatHints) return null;
    return validateHtmlStructure(processedHtml);
  }, [processedHtml, showFormatHints]);
  
  const hasGoodStructure = hasStructuredSections(processedHtml);
  
  if (!processedHtml) {
    return (
      <div className={`text-muted-foreground italic ${className}`}>
        No content available
      </div>
    );
  }
  
  return (
    <div className={className}>
      {/* Format hint for poorly structured content */}
      {showFormatHints && !hasGoodStructure && (
        <Alert className="mb-4">
          <Info className="h-4 w-4" />
          <AlertDescription>
            This content has been auto-formatted for better readability. 
            The AI may generate better structured responses with updated prompts.
          </AlertDescription>
        </Alert>
      )}
      
      {/* Validation warnings for development */}
      {showFormatHints && structureValidation && !structureValidation.valid && (
        <Alert variant="destructive" className="mb-4">
          <AlertDescription>
            <strong>Format Issues:</strong> {structureValidation.issues.join(', ')}
          </AlertDescription>
        </Alert>
      )}
      
      {/* Main content with beautiful typography */}
      <div
        className="prose prose-sm max-w-none 
                   prose-headings:text-foreground prose-headings:font-semibold
                   prose-h3:text-lg prose-h3:mt-6 prose-h3:mb-3 prose-h3:first:mt-0
                   prose-p:text-foreground prose-p:my-2 prose-p:leading-relaxed
                   prose-ul:my-3 prose-ul:space-y-1
                   prose-li:text-foreground prose-li:my-0.5 prose-li:leading-relaxed
                   prose-strong:text-foreground prose-strong:font-semibold
                   prose-em:text-foreground prose-em:italic
                   prose-a:text-primary prose-a:underline prose-a:decoration-2
                   prose-a:underline-offset-2 hover:prose-a:decoration-primary/80"
        dangerouslySetInnerHTML={{ __html: processedHtml }}
      />
    </div>
  );
}