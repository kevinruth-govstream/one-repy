import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { CheckCircle, XCircle, Lock, AlertTriangle, Clock } from "lucide-react";
import { type Section, type GatingMode, type DeptStatus } from "@/lib/store";

interface ApprovalActionsProps {
  section: Section;
  gatingMode: GatingMode;
  departmentStatuses: Record<string, DeptStatus>;
  onApprove: () => void;
  onReject: () => void;
  hasUnsavedChanges: boolean;
}

export function ApprovalActions({ 
  section, 
  gatingMode, 
  departmentStatuses,
  onApprove, 
  onReject,
  hasUnsavedChanges 
}: ApprovalActionsProps) {
  const isApprovalDisabled = section.status === 'approved' || section.status === 'locked';
  const isRejectionDisabled = section.status === 'locked';
  
  const getGatingModeDescription = () => {
    if (gatingMode === 'first') {
      return "First approval wins - approving this section will lock others.";
    }
    return "All departments must approve before ticket completion.";
  };

  const getApprovalImpact = () => {
    if (gatingMode === 'first') {
      const otherDepts = Object.entries(departmentStatuses)
        .filter(([dept, _]) => dept !== section.department)
        .filter(([_, status]) => status === 'pending');
      
      if (otherDepts.length > 0) {
        return `This will lock ${otherDepts.length} other pending section(s).`;
      }
    }
    return null;
  };

  const getStatusIcon = (status: DeptStatus) => {
    switch (status) {
      case 'pending':
        return <Clock className="h-4 w-4 text-warning" />;
      case 'annotated':
        return <AlertTriangle className="h-4 w-4 text-primary" />;
      case 'approved':
        return <CheckCircle className="h-4 w-4 text-success" />;
      case 'locked':
        return <Lock className="h-4 w-4 text-professional" />;
      default:
        return null;
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <CardTitle className="text-lg flex items-center gap-2">
          <CheckCircle className="h-5 w-5 text-primary" />
          Review Actions
        </CardTitle>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Current Status */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-foreground">Current Status</h3>
          <div className="flex items-center gap-2">
            {getStatusIcon(section.status)}
            <span className="text-sm text-foreground capitalize">
              {section.status === 'annotated' ? 'Has Annotations' : section.status}
            </span>
          </div>
        </div>

        {/* Gating Information */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-foreground">Workflow Mode</h3>
          <div className="p-3 bg-muted/50 rounded-lg border">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className={
                gatingMode === 'first' 
                  ? "bg-warning-10 text-warning border-warning-20"
                  : "bg-success-10 text-success border-success-20"
              }>
                {gatingMode === 'first' ? 'First Wins' : 'All Required'}
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground">
              {getGatingModeDescription()}
            </p>
            {getApprovalImpact() && (
              <p className="text-xs text-warning mt-1 font-medium">
                ⚠️ {getApprovalImpact()}
              </p>
            )}
          </div>
        </div>

        {/* Department Status Overview */}
        <div className="space-y-3">
          <h3 className="text-sm font-semibold text-foreground">Department Status</h3>
          <div className="grid grid-cols-2 gap-2">
            {Object.entries(departmentStatuses).map(([dept, status]) => (
              <div 
                key={dept} 
                className={`p-2 rounded border text-xs ${
                  dept === section.department 
                    ? 'bg-primary-10 border-primary-20' 
                    : 'bg-muted/50 border-border'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="capitalize font-medium">
                    {dept.replace('_', ' ')}
                  </span>
                  <div className="flex items-center gap-1">
                    {getStatusIcon(status)}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Unsaved Changes Warning */}
        {hasUnsavedChanges && (
          <div className="p-3 bg-warning-10 border border-warning-20 rounded-lg">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-warning" />
              <span className="text-sm font-medium text-warning">
                You have unsaved changes
              </span>
            </div>
            <p className="text-xs text-warning mt-1">
              Save your changes before proceeding with approval actions.
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex gap-3">
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                className="flex-1"
                disabled={isApprovalDisabled || hasUnsavedChanges}
                variant="default"
              >
                <CheckCircle className="h-4 w-4 mr-2" />
                Approve Section
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Approve Section</AlertDialogTitle>
                <AlertDialogDescription>
                  Are you sure you want to approve this section? This action cannot be undone.
                  {getApprovalImpact() && (
                    <span className="block mt-2 text-warning font-medium">
                      ⚠️ {getApprovalImpact()}
                    </span>
                  )}
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={onApprove}>
                  Approve Section
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>

          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button 
                variant="destructive"
                className="flex-1"
                disabled={isRejectionDisabled || hasUnsavedChanges}
              >
                <XCircle className="h-4 w-4 mr-2" />
                Request Changes
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Request Changes</AlertDialogTitle>
                <AlertDialogDescription>
                  This will mark the section as needing revisions and notify the department.
                  Make sure you've added detailed annotations explaining what needs to be changed.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={onReject} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                  Request Changes
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>

        {/* Status Messages */}
        {section.status === 'approved' && (
          <div className="p-3 bg-success-10 border border-success-20 rounded-lg">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-success" />
              <span className="text-sm font-medium text-success">
                Section Approved
              </span>
            </div>
          </div>
        )}

        {section.status === 'locked' && (
          <div className="p-3 bg-professional-10 border border-professional-20 rounded-lg">
            <div className="flex items-center gap-2">
              <Lock className="h-4 w-4 text-professional" />
              <span className="text-sm font-medium text-professional">
                Section Locked
              </span>
            </div>
            <p className="text-xs text-professional mt-1">
              This section was locked by the gating mode and cannot be modified.
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}