import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { GripVertical, MessageSquare } from 'lucide-react';
import { DepartmentBadge } from './DepartmentBadge';
import { Section } from '@/lib/store';

interface CompactSectionItemProps {
  section: Section;
  isVisible: boolean;
  onToggleVisibility: (sectionId: string) => void;
}

const CompactSectionItem = ({ 
  section, 
  isVisible, 
  onToggleVisibility 
}: CompactSectionItemProps) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: section.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const statusColor = {
    'pending': 'bg-yellow-100 border-yellow-300 text-yellow-800',
    'approved': 'bg-green-100 border-green-300 text-green-800',
    'rejected': 'bg-red-100 border-red-300 text-red-800'
  }[section.status] || 'bg-gray-100 border-gray-300 text-gray-800';

  const annotationCount = Array.isArray(section.annotations) ? section.annotations.length : 0;

  return (
    <div 
      ref={setNodeRef} 
      style={style} 
      className={`${isDragging ? 'opacity-50' : ''} ${isVisible ? '' : 'opacity-60'}`}
    >
      <div className={`flex items-center gap-3 p-3 rounded-lg border-2 transition-all ${statusColor}`}>
        {/* Drag Handle */}
        <button
          className="cursor-grab hover:cursor-grabbing p-1 hover:bg-black/10 rounded"
          {...attributes}
          {...listeners}
        >
          <GripVertical className="h-4 w-4" />
        </button>

        {/* Section Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="font-medium text-sm capitalize">
              {section.sectionKey.replace(/([A-Z])/g, ' $1').trim()}
            </span>
            <DepartmentBadge department={section.department} />
          </div>
        </div>

        {/* Annotations Count */}
        {annotationCount > 0 && (
          <Badge variant="outline" className="text-xs">
            <MessageSquare className="h-3 w-3 mr-1" />
            {annotationCount}
          </Badge>
        )}

        {/* Visibility Toggle */}
        <Switch
          checked={isVisible}
          onCheckedChange={() => onToggleVisibility(section.id)}
          className="scale-90"
        />
      </div>
    </div>
  );
};

interface CompactSectionManagerProps {
  sections: Section[];
  sectionOrder: string[];
  visibleSections: Set<string>;
  onToggleVisibility: (sectionId: string) => void;
  onToggleAllSections: () => void;
}

export const CompactSectionManager = ({
  sections,
  sectionOrder,
  visibleSections,
  onToggleVisibility,
  onToggleAllSections
}: CompactSectionManagerProps) => {
  const orderedSections = sectionOrder
    .map(id => sections.find(section => section.id === id))
    .filter(Boolean) as Section[];

  const allVisible = sectionOrder.every(id => visibleSections.has(id));

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-lg">Section Order</h3>
        <div className="flex items-center gap-2">
          <Badge variant="secondary" className="text-xs">
            {Array.from(visibleSections).length}/{sectionOrder.length} visible
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={onToggleAllSections}
            className="text-xs"
          >
            {allVisible ? 'Hide All' : 'Show All'}
          </Button>
        </div>
      </div>

      {/* Instructions */}
      <p className="text-sm text-muted-foreground">
        Drag to reorder sections. Toggle switches to show/hide in email.
      </p>

      {/* Section List */}
      <div className="space-y-2">
        {orderedSections.map(section => (
          <CompactSectionItem
            key={section.id}
            section={section}
            isVisible={visibleSections.has(section.id)}
            onToggleVisibility={onToggleVisibility}
          />
        ))}
      </div>

      {orderedSections.length === 0 && (
        <div className="text-center py-8 text-muted-foreground">
          <p>No approved sections available</p>
          <p className="text-sm">Complete the review process first</p>
        </div>
      )}
    </div>
  );
};