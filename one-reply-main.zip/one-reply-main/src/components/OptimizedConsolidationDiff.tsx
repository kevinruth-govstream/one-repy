import { memo, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { DepartmentBadge } from './DepartmentBadge';
import { Section } from '@/lib/store';
import { consolidateSections, formatConsolidatedSection } from '@/lib/consolidate';
import { ArrowRight, Merge, Users } from 'lucide-react';

interface ConsolidationDiffProps {
  sections: Section[];
  visibleSections: Set<string>;
}

// Memoized visible sections filter
const useVisibleSections = (sections: Section[], visibleSections: Set<string>) => {
  return useMemo(() => {
    return sections.filter(section => visibleSections.has(section.id));
  }, [sections, visibleSections]);
};

// Memoized consolidated atoms
const useConsolidatedAtoms = (visibleSectionList: Section[]) => {
  return useMemo(() => {
    return consolidateSections(visibleSectionList);
  }, [visibleSectionList]);
};

// Memoized sections by key grouping
const useSectionsByKey = (visibleSectionList: Section[]) => {
  return useMemo(() => {
    return visibleSectionList.reduce((groups, section) => {
      if (!groups[section.sectionKey]) {
        groups[section.sectionKey] = [];
      }
      groups[section.sectionKey].push(section);
      return groups;
    }, {} as Record<string, Section[]>);
  }, [visibleSectionList]);
};

// Memoized section keys
const useSectionKeys = () => {
  return useMemo(() => ['situation', 'guidance', 'nextsteps'] as const, []);
};

// Memoized individual section component
const IndividualSection = memo(({ section }: { section: Section }) => (
  <div className="bg-muted/50 p-3 rounded border-l-4 border-l-blue-500">
    <div className="flex items-center gap-2 mb-2">
      <DepartmentBadge department={section.department} />
      <Badge variant="secondary" className="text-xs">Original</Badge>
    </div>
    <div className="text-sm whitespace-pre-wrap text-muted-foreground">
      {section.content || 'No content'}
    </div>
  </div>
));

// Memoized consolidated section component
const ConsolidatedSection = memo(({ consolidatedContent }: { consolidatedContent: string }) => (
  <div className="bg-green-50 border border-green-200 p-3 rounded border-l-4 border-l-green-500">
    <div className="flex items-center gap-2 mb-2">
      <Badge variant="default" className="bg-green-600 text-xs">Consolidated</Badge>
    </div>
    <div className="text-sm whitespace-pre-wrap">
      {consolidatedContent || 'No consolidated content available'}
    </div>
  </div>
));

// Memoized processing analysis component
const ProcessingAnalysis = memo(({ sectionsCount }: { sectionsCount: number }) => (
  <div className="bg-blue-50 border border-blue-200 p-3 rounded text-sm">
    <h5 className="font-medium mb-1">AI Processing Applied:</h5>
    <ul className="text-blue-700 space-y-1">
      <li>• Similarity detection and grouping (Jaccard index)</li>
      <li>• Conflict resolution for duplicate information</li>
      <li>• Citation deduplication by code and section</li>
      <li>• Source attribution tracking</li>
      {sectionsCount > 2 && <li>• Multi-department consensus building</li>}
    </ul>
  </div>
));

// Memoized section diff card
const SectionDiffCard = memo(({ 
  sectionKey, 
  sectionsForKey, 
  consolidatedContent 
}: { 
  sectionKey: string; 
  sectionsForKey: Section[]; 
  consolidatedContent: string; 
}) => (
  <Card>
    <CardHeader>
      <CardTitle className="flex items-center gap-2 capitalize">
        <Merge className="h-5 w-5" />
        {sectionKey.replace(/([A-Z])/g, ' $1').trim()}
        <Badge variant="outline">{sectionsForKey.length} departments</Badge>
      </CardTitle>
    </CardHeader>
    <CardContent className="space-y-4">
      {/* Before - Individual Department Responses */}
      <div>
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Users className="h-4 w-4" />
          Individual Department Responses:
        </h4>
        <div className="space-y-3">
          {sectionsForKey.map((section) => (
            <IndividualSection key={section.id} section={section} />
          ))}
        </div>
      </div>

      {/* Arrow */}
      <div className="flex justify-center">
        <div className="flex items-center gap-2 text-muted-foreground">
          <Separator className="w-12" />
          <ArrowRight className="h-4 w-4" />
          <Separator className="w-12" />
        </div>
      </div>

      {/* After - Consolidated Response */}
      <div>
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Merge className="h-4 w-4" />
          AI Consolidated Response:
        </h4>
        <ConsolidatedSection consolidatedContent={consolidatedContent} />
      </div>

      {/* Analysis */}
      {sectionsForKey.length > 1 && (
        <ProcessingAnalysis sectionsCount={sectionsForKey.length} />
      )}
    </CardContent>
  </Card>
));

// Memoized empty state
const EmptyState = memo(() => (
  <div className="text-center py-8 text-muted-foreground">
    <Merge className="h-8 w-8 mx-auto mb-2 opacity-50" />
    <p>No sections selected for consolidation</p>
    <p className="text-sm">Enable section visibility to see consolidation analysis</p>
  </div>
));

export const ConsolidationDiff = memo(({ sections, visibleSections }: ConsolidationDiffProps) => {
  const visibleSectionList = useVisibleSections(sections, visibleSections);
  const consolidatedAtoms = useConsolidatedAtoms(visibleSectionList);
  const sectionsByKey = useSectionsByKey(visibleSectionList);
  const sectionKeys = useSectionKeys();

  if (visibleSectionList.length === 0) {
    return <EmptyState />;
  }

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">AI Consolidation Analysis</h3>
        <p className="text-sm text-muted-foreground">
          See how the AI algorithm merged, deduplicated, and resolved conflicts between department responses
        </p>
      </div>

      {sectionKeys.map(sectionKey => {
        const sectionsForKey = sectionsByKey[sectionKey] || [];
        if (sectionsForKey.length === 0) return null;

        const consolidatedContent = formatConsolidatedSection(sectionKey, consolidatedAtoms);

        return (
          <SectionDiffCard
            key={sectionKey}
            sectionKey={sectionKey}
            sectionsForKey={sectionsForKey}
            consolidatedContent={consolidatedContent}
          />
        );
      })}
    </div>
  );
});