import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { store } from '@/lib/store';
import { suggestDepartments } from '@/lib/departments';
import { getFolderIdByName, getNewestMessage, markProcessed } from '@/lib/graph-mail';
import { mapMessageToTicket, sanitizeHtml } from '@/lib/intake';
import { Mail, Loader2 } from 'lucide-react';

interface ImportFromOutlookProps {
  className?: string;
}

export const ImportFromOutlook: React.FC<ImportFromOutlookProps> = ({ className }) => {
  const [isImporting, setIsImporting] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleImport = async () => {
    setIsImporting(true);
    
    try {
      // Get settings from localStorage
      const settings = JSON.parse(localStorage.getItem('onereply-settings') || '{}');
      const intakeFolderName = settings.microsoft?.intakeFolderName || 'OneReply Intake';
      const markProcessedEnabled = settings.microsoft?.markProcessed || false;
      const processedFolderName = settings.microsoft?.processedFolderName || 'OneReply Processed';

      // Step 1: Find the intake folder
      toast({
        title: "Searching for folder",
        description: `Looking for "${intakeFolderName}" folder...`,
      });

      const folderId = await getFolderIdByName(intakeFolderName);
      if (!folderId) {
        toast({
          title: "Folder not found",
          description: `Could not find "${intakeFolderName}" folder in your mailbox. Please create it first.`,
          variant: "destructive"
        });
        return;
      }

      // Step 2: Get the newest message
      toast({
        title: "Checking for messages",
        description: "Looking for the newest message in the intake folder...",
      });

      const message = await getNewestMessage(folderId);
      if (!message) {
        toast({
          title: "No messages found",
          description: `No messages found in "${intakeFolderName}" folder.`,
          variant: "destructive"
        });
        return;
      }

      // Step 3: Map message to ticket format
      const ticketData = mapMessageToTicket(message);
      
      // Sanitize HTML content
      const cleanBody = sanitizeHtml(ticketData.bodyHtml);

      // Step 4: Suggest departments
      const suggestedDepts = suggestDepartments(ticketData.subject, cleanBody);

      // Step 5: Create ticket
      toast({
        title: "Creating ticket",
        description: "Converting email to OneReply ticket...",
      });

      const ticket = await store.createTicket({
        subject: ticketData.subject,
        from: `${ticketData.fromName || ticketData.fromEmail} (${ticketData.source})`,
        body: cleanBody || '(No body content)',
        departments: suggestedDepts.length > 0 ? suggestedDepts : ['transportation'],
        gatingMode: 'all',
      });

      // Step 6: Mark as processed (optional)
      if (markProcessedEnabled) {
        try {
          const processedFolderId = await getFolderIdByName(processedFolderName);
          if (processedFolderId) {
            await markProcessed(message.id, 'move', processedFolderId);
          } else {
            await markProcessed(message.id, 'read');
          }
        } catch (error) {
          console.warn('Failed to mark message as processed:', error);
          // Don't fail the import for this
        }
      }

      // Step 7: Navigate to ticket
      navigate(`/ticket/${ticket.id}`);
      
      toast({
        title: "Imported from Outlook",
        description: `Created ticket "${ticket.subject}" with ${suggestedDepts.length} suggested departments.`,
      });

    } catch (error) {
      console.error('Import failed:', error);
      toast({
        title: "Import failed",
        description: error instanceof Error ? error.message : "Failed to import email from Outlook",
        variant: "destructive"
      });
    } finally {
      setIsImporting(false);
    }
  };

  return (
    <Button
      onClick={handleImport}
      disabled={isImporting}
      variant="outline"
      className={className}
    >
      {isImporting ? (
        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
      ) : (
        <Mail className="h-4 w-4 mr-2" />
      )}
      {isImporting ? 'Importing...' : 'Import from Outlook'}
    </Button>
  );
};