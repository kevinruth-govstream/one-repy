import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { GripVertical, Eye, EyeOff } from 'lucide-react';
import { DepartmentBadge } from './DepartmentBadge';
import { Section } from '@/lib/store';
import { formatConsolidatedSection } from '@/lib/consolidate';

interface DraggableSectionProps {
  section: Section;
  isVisible: boolean;
  onToggleVisibility: (sectionId: string) => void;
  isConsolidated: boolean;
}

export const DraggableSection = ({ 
  section, 
  isVisible, 
  onToggleVisibility, 
  isConsolidated 
}: DraggableSectionProps) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: section.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const content = isConsolidated 
    ? formatConsolidatedSection(section.sectionKey, section.atoms)
    : section.content;

  return (
    <div ref={setNodeRef} style={style} className={isDragging ? 'opacity-50' : ''}>
      <Card className={`transition-all duration-200 ${isVisible ? '' : 'opacity-60'}`}>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <div className="flex items-center gap-2">
            <button
              className="cursor-grab hover:cursor-grabbing p-1 hover:bg-muted rounded"
              {...attributes}
              {...listeners}
            >
              <GripVertical className="h-4 w-4 text-muted-foreground" />
            </button>
            <CardTitle className="text-lg capitalize">
              {section.sectionKey.replace(/([A-Z])/g, ' $1').trim()}
            </CardTitle>
            <DepartmentBadge department={section.department} />
            <Badge variant="secondary">{section.status}</Badge>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              checked={isVisible}
              onCheckedChange={() => onToggleVisibility(section.id)}
              className="data-[state=checked]:bg-primary"
            />
            {isVisible ? (
              <Eye className="h-4 w-4 text-muted-foreground" />
            ) : (
              <EyeOff className="h-4 w-4 text-muted-foreground" />
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-0">
          <div className="prose prose-sm max-w-none text-foreground">
            <div className="whitespace-pre-wrap">{content}</div>
          </div>
          {section.atoms.guidance?.citations?.length > 0 && (
            <div className="mt-4 pt-4 border-t">
              <h4 className="font-medium mb-2">Citations:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                {section.atoms.guidance.citations.map((citation, index) => (
                  <li key={index}>
                    <strong>{citation.code}</strong> - {citation.description}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};