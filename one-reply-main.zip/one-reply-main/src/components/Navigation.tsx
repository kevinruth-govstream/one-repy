import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Settings, FileText, Home, Archive, LogOut } from "lucide-react";
import { OneReplyLogo } from "./OneReplyLogo";
import { useAuth } from "@/hooks/useAuth";

export function Navigation() {
  const location = useLocation();
  const currentPath = location.pathname;
  const { signOut, user } = useAuth();

  const isActive = (path: string) => currentPath === path;

  return (
    <Card className="border-b rounded-none bg-card shadow-sm">
      <div className="container mx-auto px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-6">
            <Link to="/" className="flex items-center">
              <OneReplyLogo size="md" />
            </Link>
            
            <nav className="flex items-center space-x-4">
              <Link to="/ticket/new">
                <Button 
                  variant="default"
                  size="sm"
                  className="flex items-center space-x-2 bg-primary text-primary-foreground hover:bg-primary-hover"
                >
                  <FileText className="h-4 w-4" />
                  <span>Create New Ticket</span>
                </Button>
              </Link>
              
              <Link to="/">
                <Button 
                  variant="ghost"
                  size="sm"
                  className="flex items-center space-x-2"
                >
                  <Home className="h-4 w-4" />
                  <span>Dashboard</span>
                </Button>
              </Link>
              
              <Link to="/archive">
                <Button 
                  variant={isActive("/archive") ? "default" : "ghost"} 
                  size="sm"
                  className="flex items-center space-x-2"
                >
                  <Archive className="h-4 w-4" />
                  <span>Archive</span>
                </Button>
              </Link>
              
              <Link to="/settings">
                <Button 
                  variant={isActive("/settings") ? "default" : "ghost"} 
                  size="sm"
                  className="flex items-center space-x-2"
                >
                  <Settings className="h-4 w-4" />
                  <span>Settings</span>
                </Button>
              </Link>
            </nav>
          </div>
          
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              {user?.email}
            </span>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={signOut}
              className="flex items-center gap-2"
            >
              <LogOut className="h-4 w-4" />
              Sign Out
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}