import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { DepartmentBadge } from "./DepartmentBadge";
import { StatusIndicator } from "./StatusIndicator";
import { type Section } from "@/lib/store";
import { getDepartment } from "@/lib/departments";
import { Clock, Calendar, User } from "lucide-react";
import { useState } from "react";

interface SectionReviewCardProps {
  section: Section;
  onContentChange: (content: string) => void;
}

export function SectionReviewCard({ section, onContentChange }: SectionReviewCardProps) {
  const [content, setContent] = useState(section.content);
  const department = getDepartment(section.department);

  const handleContentChange = (value: string) => {
    setContent(value);
    onContentChange(value);
  };

  const formatSectionTitle = (key: string) => {
    return key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
  };

  return (
    <Card className="w-full">
      <CardHeader className="pb-4">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <CardTitle className="text-xl font-semibold text-foreground">
              {formatSectionTitle(section.sectionKey)}
            </CardTitle>
            <div className="flex items-center gap-2">
              <DepartmentBadge department={section.department} />
              <StatusIndicator status={section.status} />
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1">
            <Calendar className="h-4 w-4" />
            <span>Created {section.createdAt.toLocaleDateString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>Updated {section.updatedAt.toLocaleDateString()}</span>
          </div>
          <div className="flex items-center gap-1">
            <User className="h-4 w-4" />
            <span>{department.name}</span>
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Structured Atoms Display */}
        {Object.entries(section.atoms).some(([_, value]) => 
          Array.isArray(value) ? value.length > 0 : value
        ) && (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold text-foreground">Structured Content</h3>
            
            {/* Render based on section type */}
            {section.sectionKey === 'situation' && section.atoms.situation?.understanding?.length > 0 && (
              <div className="space-y-2">
                <Badge variant="outline">Understanding</Badge>
                <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                  {section.atoms.situation.understanding.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>
            )}

            {section.sectionKey === 'guidance' && section.atoms.guidance?.recommendations?.length > 0 && (
              <div className="space-y-2">
                <Badge variant="outline">Recommendations</Badge>
                <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground ml-4">
                  {section.atoms.guidance.recommendations.map((item, index) => (
                    <li key={index}>{item}</li>
                  ))}
                </ul>
              </div>
            )}

            <Separator />
          </div>
        )}

        {/* Editable Content */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-foreground">Draft Content</h3>
            <Badge variant="outline" className="text-xs">
              {content.length} characters
            </Badge>
          </div>
          
          <Textarea
            value={content}
            onChange={(e) => handleContentChange(e.target.value)}
            className="min-h-[200px] font-mono text-sm"
            placeholder="Edit the section content here..."
          />
        </div>

        {/* Annotations */}
        {section.annotations.length > 0 && (
          <div className="space-y-3">
            <Separator />
            <h3 className="text-sm font-semibold text-foreground">Previous Annotations</h3>
            <div className="space-y-2">
              {section.annotations.map((annotation, index) => (
                <div key={index} className="p-3 bg-muted/50 rounded border text-sm">
                  {annotation}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}