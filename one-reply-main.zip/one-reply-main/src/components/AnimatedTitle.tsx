import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { OneReplyLogo } from "./OneReplyLogo";

interface AnimatedTitleProps {
  className?: string;
}

export function AnimatedTitle({ className }: AnimatedTitleProps) {
  const [phase, setPhase] = useState(0);
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const sequence = [
      // Phase 0: "One City" (2 seconds)
      { delay: 0, action: () => { setPhase(0); setIsVisible(true); } },
      
      // Phase 1: Fade out "One City" (0.5 seconds)
      { delay: 2000, action: () => setIsVisible(false) },
      
      // Phase 2: "One Voice" (0.5s delay + 2 seconds display)
      { delay: 2500, action: () => { setPhase(1); setIsVisible(true); } },
      
      // Phase 3: Fade out "One Voice" (0.5 seconds)
      { delay: 4500, action: () => setIsVisible(false) },
      
      // Phase 4: "OneReply" with logo (final state)
      { delay: 5000, action: () => { setPhase(2); setIsVisible(true); } },
    ];

    const timeouts = sequence.map(({ delay, action }) =>
      setTimeout(action, delay)
    );

    return () => {
      timeouts.forEach(clearTimeout);
    };
  }, []);

  const titles = [
    "One City",
    "One Voice",
    "OneReply"
  ];

  const titleColors = [
    "text-foreground",
    "text-foreground", 
    "text-foreground"
  ];

  return (
    <div className={cn("flex items-center justify-center h-full", className)}>
      {phase === 2 && (
        <div className={cn(
          "flex items-center justify-center transition-all duration-500",
          isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
        )}>
          <OneReplyLogo size="lg" className="text-foreground" />
        </div>
      )}
      
      {phase < 2 && (
        <h1 className={cn(
          "text-4xl font-bold tracking-tight transition-all duration-500 ease-in-out transform",
          titleColors[phase],
          isVisible 
            ? "opacity-100 translate-y-0 scale-100" 
            : "opacity-0 translate-y-4 scale-95"
        )}>
          {titles[phase]}
        </h1>
      )}
    </div>
  );
}