import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DepartmentBadge } from './DepartmentBadge';
import { ConsolidationDiff } from './ConsolidationDiff';
import { IndividualSectionsView } from './IndividualSectionsView';
import { Section } from '@/lib/store';
import { formatConsolidatedSection } from '@/lib/consolidate';
import { Mail, Calendar, User, FileText, Merge, Users, Edit3, Save, X } from 'lucide-react';

interface EmailPreviewProps {
  sections: Section[];
  visibleSections: Set<string>;
  isConsolidated: boolean;
  intro: string;
  outro: string;
  onIntroChange: (intro: string) => void;
  onOutroChange: (outro: string) => void;
  ticketId?: string;
}

interface UnifiedResponseViewProps {
  sections: Section[];
  visibleSections: Set<string>;
  intro: string;
  outro: string;
  ticketId?: string;
  editingIntro: boolean;
  editingOutro: boolean;
  tempIntro: string;
  tempOutro: string;
  onEditIntro: () => void;
  onEditOutro: () => void;
  onSaveIntro: () => void;
  onSaveOutro: () => void;
  onCancelIntro: () => void;
  onCancelOutro: () => void;
  onTempIntroChange: (value: string) => void;
  onTempOutroChange: (value: string) => void;
}

// Component for the unified response email preview
const UnifiedResponseView = ({ 
  sections, 
  visibleSections, 
  intro, 
  outro, 
  ticketId,
  editingIntro,
  editingOutro,
  tempIntro,
  tempOutro,
  onEditIntro,
  onEditOutro,
  onSaveIntro,
  onSaveOutro,
  onCancelIntro,
  onCancelOutro,
  onTempIntroChange,
  onTempOutroChange
}: UnifiedResponseViewProps) => {
  const visibleSectionList = sections.filter(section => visibleSections.has(section.id));
  
  // Group sections by type and consolidate for 3-section structure
  const sectionGroups = visibleSectionList.reduce((groups, section) => {
    if (!groups[section.sectionKey]) {
      groups[section.sectionKey] = [];
    }
    groups[section.sectionKey].push(section);
    return groups;
  }, {} as Record<string, Section[]>);

  const sectionKeys = ['situation', 'guidance', 'nextsteps'] as const;

  return (
    <div className="space-y-4">
      {/* Email Header */}
      <div className="bg-muted/50 p-4 rounded-lg">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="flex items-center gap-2">
            <User className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">From:</span>
            <span>OneReply Support</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">Date:</span>
            <span>{new Date().toLocaleDateString()}</span>
          </div>
          <div className="col-span-2">
            <span className="font-medium">Subject:</span>
            <span className="ml-2">Response to Ticket #{ticketId?.slice(-6) || 'XXXXXX'}</span>
          </div>
        </div>
      </div>

      {/* Email Body */}
      <div className="bg-background border rounded-lg p-6 space-y-6 max-h-[600px] overflow-y-auto">
        {/* Introduction */}
        <div className="group">
          {editingIntro ? (
            <div className="space-y-2">
              <Textarea
                value={tempIntro}
                onChange={(e) => onTempIntroChange(e.target.value)}
                className="min-h-20 resize-none"
                placeholder="Enter email introduction..."
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={onSaveIntro}>
                  <Save className="h-3 w-3 mr-1" />
                  Save
                </Button>
                <Button size="sm" variant="outline" onClick={onCancelIntro}>
                  <X className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="relative">
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-foreground pr-8">{intro}</div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={onEditIntro}
              >
                <Edit3 className="h-3 w-3" />
              </Button>
            </div>
          )}
        </div>

        <Separator />

        {/* Unified Sections */}
        <div className="space-y-6">
          {sectionKeys.map(sectionKey => {
            const sectionsForKey = sectionGroups[sectionKey] || [];
            if (sectionsForKey.length === 0) return null;

            // If only one section, show its content directly
            // If multiple sections, show consolidated content
            let content = '';
            if (sectionsForKey.length === 1) {
              content = sectionsForKey[0].content || 'No content available';
            } else {
              // For multiple sections, show a combined view
              content = sectionsForKey.map((section, idx) => 
                `${section.content || 'No content'}`
              ).join('\n\n');
            }

            return (
              <div key={sectionKey} className="space-y-3">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-lg capitalize">
                    {sectionKey.replace(/([A-Z])/g, ' $1').trim()}
                  </h3>
                  <Badge variant="outline">
                    {sectionsForKey.length} dept{sectionsForKey.length !== 1 ? 's' : ''}
                  </Badge>
                  {sectionsForKey.length > 1 && (
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      Unified
                    </Badge>
                  )}
                </div>
                <div className="prose prose-sm max-w-none text-foreground">
                  <div className={`whitespace-pre-wrap p-4 rounded border ${
                    sectionsForKey.length > 1 
                      ? 'bg-green-50 border-green-200' 
                      : 'bg-muted/30 border-muted'
                  }`}>
                    {content}
                  </div>
                </div>

                {/* Show citations for this section if available */}
                {sectionsForKey.some(s => s.atoms.guidance?.citations?.length > 0) && (
                  <div className="bg-blue-50 border border-blue-200 p-3 rounded text-sm">
                    <p className="font-medium mb-2">Referenced Regulations:</p>
                    <ul className="space-y-1">
                      {sectionsForKey.flatMap(s => s.atoms.guidance?.citations || []).map((citation, citIndex) => (
                        <li key={citIndex} className="text-blue-700">
                          <strong>{citation.code}</strong> {citation.section && `§${citation.section}`} - {citation.description}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Outro */}
        <Separator />
        <div className="group">
          {editingOutro ? (
            <div className="space-y-2">
              <Textarea
                value={tempOutro}
                onChange={(e) => onTempOutroChange(e.target.value)}
                className="min-h-20 resize-none"
                placeholder="Enter email conclusion..."
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={onSaveOutro}>
                  <Save className="h-3 w-3 mr-1" />
                  Save
                </Button>
                <Button size="sm" variant="outline" onClick={onCancelOutro}>
                  <X className="h-3 w-3 mr-1" />
                  Cancel
                </Button>
              </div>
            </div>
          ) : (
            <div className="relative">
              <div className="prose prose-sm max-w-none">
                <div className="whitespace-pre-wrap text-foreground pr-8">{outro}</div>
              </div>
              <Button
                size="sm"
                variant="ghost"
                className="absolute -top-1 -right-1 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={onEditOutro}
              >
                <Edit3 className="h-3 w-3" />
              </Button>
            </div>
          )}
        </div>

        {/* OneReply Footer */}
        <Separator />
        <div className="text-sm text-muted-foreground italic text-center pt-4 border-t">
          Prepared with OneReply — one city, one voice.
        </div>
      </div>
    </div>
  );
};

export const EmailPreview = ({ 
  sections, 
  visibleSections, 
  isConsolidated, 
  intro, 
  outro,
  onIntroChange,
  onOutroChange,
  ticketId 
}: EmailPreviewProps) => {
  const [editingIntro, setEditingIntro] = useState(false);
  const [editingOutro, setEditingOutro] = useState(false);
  const [tempIntro, setTempIntro] = useState(intro);
  const [tempOutro, setTempOutro] = useState(outro);

  const handleSaveIntro = () => {
    onIntroChange(tempIntro);
    setEditingIntro(false);
  };

  const handleCancelIntro = () => {
    setTempIntro(intro);
    setEditingIntro(false);
  };

  const handleSaveOutro = () => {
    onOutroChange(tempOutro);
    setEditingOutro(false);
  };

  const handleCancelOutro = () => {
    setTempOutro(outro);
    setEditingOutro(false);
  };
  const visibleSectionList = sections.filter(section => visibleSections.has(section.id));
  const totalWords = (intro + outro + visibleSectionList.map(s => s.content).join(' ')).split(' ').length;
  const estimatedReadTime = Math.ceil(totalWords / 200);

  return (
    <Card className="h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Email Response
          </CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline">
              {totalWords} words
            </Badge>
            <Badge variant="outline">
              ~{estimatedReadTime} min read
            </Badge>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="unified" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="unified" className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Unified Response
            </TabsTrigger>
            <TabsTrigger value="individual" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Individual Sections
            </TabsTrigger>
            <TabsTrigger value="diff" className="flex items-center gap-2">
              <Merge className="h-4 w-4" />
              Consolidation Diff
            </TabsTrigger>
          </TabsList>

          <div className="mt-4">
            <TabsContent value="unified" className="space-y-4">
              <UnifiedResponseView 
                sections={sections}
                visibleSections={visibleSections}
                intro={intro}
                outro={outro}
                ticketId={ticketId}
                editingIntro={editingIntro}
                editingOutro={editingOutro}
                tempIntro={tempIntro}
                tempOutro={tempOutro}
                onEditIntro={() => setEditingIntro(true)}
                onEditOutro={() => setEditingOutro(true)}
                onSaveIntro={handleSaveIntro}
                onSaveOutro={handleSaveOutro}
                onCancelIntro={handleCancelIntro}
                onCancelOutro={handleCancelOutro}
                onTempIntroChange={setTempIntro}
                onTempOutroChange={setTempOutro}
              />
            </TabsContent>

            <TabsContent value="individual">
              <IndividualSectionsView 
                sections={sections}
                visibleSections={visibleSections}
              />
            </TabsContent>

            <TabsContent value="diff">
              <ConsolidationDiff 
                sections={sections}
                visibleSections={visibleSections}
              />
            </TabsContent>
          </div>
        </Tabs>

        {/* Footer Stats */}
        <div className="text-xs text-muted-foreground bg-muted/30 p-3 rounded mt-4">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <span className="font-medium">Sections:</span> {visibleSectionList.length}
            </div>
            <div>
              <span className="font-medium">Departments:</span> {new Set(visibleSectionList.map(s => s.department)).size}
            </div>
            <div>
              <span className="font-medium">Status:</span> {sections.filter(s => s.status === 'approved').length}/{sections.length} approved
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};