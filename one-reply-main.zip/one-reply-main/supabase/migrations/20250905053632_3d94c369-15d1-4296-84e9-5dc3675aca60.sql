-- Add 'omitted' to the dept_status enum
ALTER TYPE dept_status ADD VALUE 'omitted';